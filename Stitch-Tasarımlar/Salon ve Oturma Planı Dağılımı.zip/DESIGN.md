---
name: SınavPlan Design System
colors:
  surface: '#f8f9fb'
  surface-dim: '#d9dadc'
  surface-bright: '#f8f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#edeef0'
  surface-container-high: '#e7e8ea'
  surface-container-highest: '#e1e2e4'
  on-surface: '#191c1e'
  on-surface-variant: '#454654'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f3'
  outline: '#757686'
  outline-variant: '#c5c5d7'
  surface-tint: '#3d4fd3'
  primary: '#3b4cd0'
  on-primary: '#ffffff'
  primary-container: '#5667eb'
  on-primary-container: '#fffbff'
  inverse-primary: '#bcc2ff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#904900'
  on-tertiary: '#ffffff'
  tertiary-container: '#b55d00'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dfe0ff'
  primary-fixed-dim: '#bcc2ff'
  on-primary-fixed: '#000b63'
  on-primary-fixed-variant: '#2033bb'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffdcc5'
  tertiary-fixed-dim: '#ffb783'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#703700'
  background: '#f8f9fb'
  on-background: '#191c1e'
  surface-variant: '#e1e2e4'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
  headline-lg:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
  headline-md:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
  body-default:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-strong:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '600'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
  body-sm-strong:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '600'
    lineHeight: 1.25rem
  label-caps:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.05em
  label-table:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

Bu tasarım sistemi; üniversite sınav koordinasyon ofisleri, bölüm sekreterlikleri, fakülte dekanlıkları ve gözetmen öğretim elemanları için kurgulanmış kurumsal, sakin ve operasyonel netliği merkeze alan bir arayüz dilidir. 

Yoğun sınav haftalarında kullanıcıların karşılaştığı derslik çakışmaları, gözetmen dengeleme yükü ve karmaşık oturum çizelgeleri gibi stres unsurlarını hafifletmek adına görsel gürültü tamamen ortadan kaldırılmıştır. Tasarım yönelimi **Modern Kurumsal SaaS (Corporate / Modern Minimal)** çizgisindedir; abartılı gradyanlar, dikkat dağıtan animasyonlar veya agresif renk blokları barındırmaz. 

Temel hedefler:
- **Akademik Ciddiyet ve Sakinlik:** Güven telkin eden yumuşak çivit mavisi (soft indigo), göz yormayan açık gri arka planlar ve dengeli beyaz kart yapıları.
- **Bilişsel Netlik:** Tablo yoğun veri görünümlerinde ve takvim matrislerinde hiyerarşik netlik; zebra çizgiler yerine hafif ve zarif sınır çizgileriyle ayrılmış okunabilir satırlar.
- **Öngörülebilirlik:** Maksimum iki ağırlık (Regular 400 ve SemiBold 600) ile sınırlandırılmış sade tipografi, tutarlı 12px köşe kavisleri ve sistemik durum rozetleri.

## Colors

Renk paleti, operasyonel iş akışlarında karar almayı kolaylaştırmak üzere yapılandırılmıştır. Öncelikli eylemler, seçili durumlar ve marka vurgusu yumuşak çivit mavisi (`#5B6CF0`) ile temsil edilirken; arka plan, yüzey ve durum göstergeleri kesin işlevsel kurallarla ayrılmıştır.

### Temel Palet
- **Birincil (Primary):** `#5B6CF0` — Birincil aksiyon butonları, aktif navigasyon ögeleri, odaklanmış girdi çerçeveleri ve seçili sekme alt çizgileri.
- **İkincil / Nötr Vurgu (Secondary / Slate):** `#64748B` — İkincil metinler, tablo başlık metinleri, pasif ikonlar ve taslak oturum durumları.
- **Tuval Arka Planı (Background Canvas):** `#F7F8FA` — Tüm ekranların temel arka planı; saf beyaz yüzeyleri belirginleştiren mat, açık gri katman.
- **Yüzey (Surface / Card):** `#FFFFFF` — Tablolar, filtre panelleri, modal pencereleri ve bilgi kartları için kullanılan saf beyaz.
- **Arayüz Kenarlıkları (Border):** `#E5E7EB` — Tablo satır ayırıcıları, girdi kutusu sınırları ve kart sınırları için hafif, kurumsal sınır rengi.

### Durum ve Semantik Renkler
Durum renkleri arayüzde dekoratif amaçla kullanılamaz; yalnızca sınav oturumu, salon kapasitesi ve gözetmen atama durumlarını belirtmekle sınırlıdır:
- **Başarılı / Onaylandı (Success):** `#3BAA7A` — Onaylanmış sınav programı, tamamlanan gözetmen ataması, yeterli salon kapasitesi.
- **Uyarı / Çakışma Riski (Warning):** `#E3A008` — Henüz atanmamış gözetmen, kapasite sınırına yaklaşan salon, taslak oturum.
- **Tehlike / Kritik Çakışma (Danger):** `#E5484D` — Derslik veya gözetmen çakışması, eksik sınav oturumu, kapasite aşımı.
- **Nötr Bilgi (Neutral Slate):** `#64748B` — Planlama dışı, muaf veya arşivlenmiş oturumlar.

## Typography

Tipografi sistemi bütünüyle **Inter** ailesi üzerine kuruludur. Görsel dinginliği korumak ve bilişsel yükü en aza indirmek amacıyla arayüz genelinde kural olarak yalnızca iki font ağırlığına izin verilir: **Regular (400)** ve **SemiBold (600)**. 

### Kullanım İlkeleri
- **Gövde Metni Standartı (15px):** Okunabilirlik ile veri yoğunluğu arasındaki dengeyi sağlamak için standart metin boyutu `15px` (`0.9375rem`) olarak sabitlenmiştir. Satır yüksekliği ferah bir akış için `24px` (`1.5rem`) düzeyindedir.
- **Tablo Başlıkları ve Meta Bilgiler:** Tablo kolon başlıkları, oturum saat kodları ve salon filtre etiketleri `12px` (`0.75rem`), SemiBold ağırlıkta ve tablolarda hafif büyük harf aralığıyla sunulur.
- **Ağırlık Disiplini:** Vurgulamalar için ekstra kalın (Bold 700/800) veya ince (Light 300) ağırlıklar kesinlikle kullanılmaz. Hiyerarşi yalnızca SemiBold (600) ve metin renk kontrastı (`#1E293B` birincil metin, `#64748B` ikincil açıklama) ile kurulur.

## Layout & Spacing

Tasarım sistemi 8pt temel ızgara sistemini benimser ve akıcı bir yerleşim modeli (Fluid Grid) kullanır. Yönetim paneli sol tarafta 260px sabit genişlikli dikey navigasyon çubuğu ve sağda dinamik genişleyen ana içerik tuvalinden oluşur.

### Izgara ve Kesim Noktaları (Breakpoints)
- **Masaüstü (Desktop ≥ 1280px):** 12 sütunlu akıcı ızgara, `2rem` (32px) dış tuval kenar boşluğu, `1.5rem` (24px) sütun olukları. Eşzamanlı takvim matrisleri ve çoklu salon görünümü tam genişlikte çalışır.
- **Tablet (768px – 1279px):** 8 sütunlu ızgara, `1.5rem` (24px) kenar boşlukları. Filtre çubukları yatay kaydırılabilir hale gelir, navigasyon simge moduna daralır.
- **Mobil (< 768px):** 4 sütunlu ızgara, `1rem` (16px) kenar boşluğu ve oluklar. Büyük veri tabloları kart görünümüne veya dikey akışlı oturum kartlarına dönüşür.

### Boşluk Hiyerarşisi
- `space-xs` (4px): İkon ile etiket arası mesafe, rozet içi dikey boşluk.
- `space-sm` (8px): Form alanları arası dikey boşluk, buton içi dikey dolgu, etiket-girdi mesafesi.
- `space-md` (16px): Standart kart içi dolgu (padding), filtre kontrol elemanları arası mesafe.
- `space-lg` (24px): Kartlar arası boşluk, modal pencere iç dolgusu, sekme içerik ayırıcıları.
- `space-xl` (32px): Sayfa başlığı ile içerik blokları arası mesafe, ana dashboard panelleri arası ayrım.

## Elevation & Depth

Sınav planlama operasyonlarında derinlik; karmaşık gölgeler veya katmanlı bulanıklıklarla değil, net yüzey sınırları ve kontrollü, ultra hafif ortam gölgeleriyle sağlanır.

### Derinlik İlkeleri
- **Yüzey Katmanı (Surface Tiers):** Arka plan `#F7F8FA` üzerinde yer alan tüm işlevsel modüller `#FFFFFF` zeminli paneller içine alınır. Paneller birbirinden `1px solid #E5E7EB` kenarlık çizgisi ile ayrılır.
- **Kart ve Panel Gölgesi:** Kart ve panellerde yalnızca `box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05)` uygulanır. Bu gölge yüzeyin tuval üzerinde hafifçe ayrışmasını sağlar ancak derinlik hissini abartmaz.
- **Açılır Menüler ve Seçim Kutuları (Dropdown & Popover):** Filtre pencereleri, gözetmen atama listeleri ve tarih seçiciler için bir üst katman derinliği uygulanır: `box-shadow: 0 4px 12px 0 rgba(0, 0, 0, 0.08)`. Kenarlık yine `#E5E7EB` olarak korunur.
- **Modal Pencereleri:** Kritik onay ve salon atama modalleri ekran merkezinde `box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)` ile yükselir. Arkasındaki karartma katmanı (backdrop) `%40` opaklıkta `#0F172A` rengindedir.

## Shapes

Tasarım sistemi genelinde geometri, kurumsal ciddiyet ile modern arayüz yumuşaklığını dengeleyen **12px (`rounded-lg`)** yapısal kavis üzerine kurgulanmıştır.

### Şekil Kuralları
- **Yüzey Kartları ve Paneller:** Tam olarak `12px` köşe yarıçapı ile sınırlandırılır. Kartların içindeki tablolar, üst ve alt köşelere taşmayacak şekilde aynı kavise uyum sağlar.
- **Form Elemanları ve Butonlar:** Girdi alanları, seçim menüleri ve butonlar `8px` kavis değerine sahiptir. Bu değer el ve imleç etkileşimlerinde net bir odak alanı sağlar.
- **Durum Rozetleri (Status Badges) ve Sayaçlar:** Oturum durumu ve gözetmen rol rozetleri `6px` hafif kavisle veya tam yuvarlatılmış (pill: `9999px`) küçük kapsül formunda sunulur.
- **İkon Konteynerleri:** Tablo aksiyon ikonları veya bildirim kutuları `8px` kavisli kare alanlarda ortalanır.

## Components

Tüm arayüz bileşenleri tutarlı form kurallarına, erişilebilir kontrast seviyelerine ve kurumsal Türkçe metin standartlarına tabidir. İkonografi için ince ve net çizgilere sahip Lucide tarzı 1.5px konturlu çizgi ikonlar kullanılır.

### 1. Butonlar (Buttons)
- **Birincil Buton:** Zemin `#5B6CF0`, metin `#FFFFFF`, yükseklik `40px`, köşe kavisi `8px`, iç dolgu `0 16px`. Üzerine gelindiğinde (hover) arka plan koyulaşır (`#4A5AE0`).
- **İkincil / Nötr Buton:** Zemin `#FFFFFF`, kenarlık `1px solid #E5E7EB`, metin `#334155`. Hover durumunda zemin `#F8FAFC`.
- **Kritik Eylem Butonu:** Sınav iptali veya oturum silme gibi işlemler için zemin `#FFFFFF`, kenarlık `1px solid #FCA5A5`, metin `#E5484D`. Hover durumunda zemin `#FEF2F2`.

### 2. Tablolar (Data Tables)
- **Yapı:** Kesinlikle alternatif satır renklendirmesi (zebra stripe) kullanılmaz. Bütün satırlar `#FFFFFF` zemin üzerinde yer alır.
- **Satır Ayırıcılar:** Her satır arasında ince, narin `1px solid #F1F5F9` kenarlık bulunur. Satır üzerine gelindiğinde (hover) satır zemini hafifçe `#F8FAFC` rengine döner.
- **Sabit Başlıklar (Sticky Header):** Çok satırlı sınav listelerinde sayfa kaydırılırken tablo başlığı tepeye yapışır (`sticky top-0`). Başlık zemini `#FFFFFF`, alt çizgisi `1px solid #E5E7EB` ve metin stili `label-table` (`#64748B`, 12px SemiBold) olarak sabit kalır.

### 3. Durum Rozetleri (Status Badges)
Durum rozetleri açık zemin üzerine koyu metin kombinasyonuyla üretilir (erişilebilir kontrast):
- **Onaylandı / Hazır:** Zemin `#ECFDF5`, Kenarlık `#A7F3D0`, Metin `#065F46`.
- **Eksik Gözetmen / Taslak:** Zemin `#FEFCE8`, Kenarlık `#FDE047`, Metin `#854D0E`.
- **Çakışma / Hata:** Zemin `#FEF2F2`, Kenarlık `#FECACA`, Metin `#991B1B`.
- **Rol Rozeti (Başgözetmen / Yedek):** Zemin `#F1F5F9`, Kenarlık `#CBD5E1`, Metin `#334155`.

### 4. Form Elemanları ve Filtreler
- **Metin Girdileri ve Seçim Kutuları:** Yükseklik `40px`, köşe kavisi `8px`, zemin `#FFFFFF`, kenarlık `1px solid #E5E7EB`, metin `15px Inter Regular`. Odaklanma (focus) anında kenarlık `#5B6CF0` olur ve `0 0 0 3px rgba(91, 108, 240, 0.15)` dış ışıma eklenir.
- **Onay Kutusu ve Radyo Butonları:** Seçili durumda zemin `#5B6CF0`, onay işareti beyaz. Pasif durumda sınır `#CBD5E1`.

### 5. Kartlar ve Bilgi Panelleri
- Yüzey saf beyaz (`#FFFFFF`), kenarlık `1px solid #E5E7EB`, köşe kavisi `12px`, gölge `0 1px 3px rgba(0,0,0,0.05)`.
- Kart başlık bölümü ve içerik bölümü gerektiğinde `1px solid #F1F5F9` ile ayrılır; gereksiz kalın ayraçlardan kaçınılır.

### 6. Çakışma Uyarı Bildirimi (Conflict Banner)
Sınav planlama ekranında tespit edilen salon ve saat çakışmaları için ekranın üst kısmında beliren özel uyarı bandı:
- Sol kenarında `4px solid #E5484D` vurgusu olan açık kırmızı kart (`#FEF2F2`), `12px` köşe kavisi, sağ tarafta "Çakışmayı Çöz" ikincil aksiyon butonu.